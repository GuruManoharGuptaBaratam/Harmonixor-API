document.addEventListener("DOMContentLoaded", () => {

  const mainPage = document.getElementById("mainPage");
  const settingsPage = document.getElementById("settingsPage");

  const settingsBtn = document.getElementById("settingsBtn");
  const backBtn = document.getElementById("backBtn");

  const emailInput = document.getElementById("email");
  const apiKeyInput = document.getElementById("apiKey");
  const automationToggle = document.getElementById("automationToggle");
  const saveBtn = document.getElementById("saveSettingsBtn");

  const statusBox = document.createElement("p"); 
  const uploadMessage = document.createElement("p");
  const historyStamp = document.createElement("p");

  statusBox.id = "statusMessage";
  uploadMessage.id = "uploadMessage";
  historyStamp.id = "historyStamp";

  [statusBox, uploadMessage, historyStamp].forEach(p => {
    p.style.fontSize = "12px";
    p.style.marginTop = "6px";
    p.style.textAlign = "center";
    settingsPage.appendChild(p);
  });

  const exportBtn = document.getElementById("exportBtn");

  function loadCookies() {
    chrome.runtime.sendMessage({ action: "getCookies" }, (response) => {
      if (response && response.content) {
        fillCookieTable(response.content);
      }
    });
  }
  loadCookies();

  exportBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "getCookies" }, (response) => {
      if (!response || !response.content) {
        alert("No cookies found!");
        return;
      }
      downloadTextFile(response.content, "youtube_cookies.txt");
    });
  });

  function fillCookieTable(cookieFileContent) {
    const tbody = document.querySelector("#cookieTable tbody");
    tbody.innerHTML = "";

    const lines = cookieFileContent.split("\n").filter(line => line && !line.startsWith("#"));
    lines.forEach(line => {
      const parts = line.split("\t"); 
      const domain = parts[0];
      const includeSubdomains = parts[1];
      const path = parts[2];
      const secure = parts[3];
      const expiry = parts[4];
      const name = parts[5];
      const value = parts[6];

      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${domain}</td>
        <td>${includeSubdomains}</td>
        <td>${path}</td>
        <td>${secure}</td>
        <td>${expiry}</td>
        <td>${name}</td>
        <td>${value}</td>
      `;
      tbody.appendChild(row);
    });
  }

  function downloadTextFile(content, filename) {
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }


  settingsBtn.addEventListener("click", () => {
    mainPage.style.display = "none";
    settingsPage.style.display = "flex";
  });
  backBtn.addEventListener("click", () => {
    settingsPage.style.display = "none";
    mainPage.style.display = "block";
  });


  chrome.storage.local.get(["email", "apiKey", "automationEnabled", "statusMessage", "lastUpload"], (data) => {
    if (data.email) emailInput.value = data.email;
    if (data.apiKey) apiKeyInput.value = data.apiKey;
    automationToggle.checked = data.automationEnabled || false;
    statusBox.textContent = data.statusMessage || "";
    historyStamp.textContent = data.lastUpload ? "Last upload: " + data.lastUpload : "";
  });


  saveBtn.addEventListener("click", async () => {
    const email = emailInput.value.trim();
    const apiKey = apiKeyInput.value.trim();
    const enabled = automationToggle.checked;

    if (!email || !apiKey) {
      statusBox.textContent = "Please fill in all fields.";
      statusBox.style.color = "red";
      return;
    }

    statusBox.textContent = "Validating...";
    statusBox.style.color = "black";
    uploadMessage.textContent = "";

    try {
      const res = await fetch("https://harmonixor-api-1.onrender.com/harmonixor/extension/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, apiKey })
      });

      const result = await res.json();

      if (res.ok && result.success) {
        statusBox.textContent = "Validation successful";
        statusBox.style.color = "green";


        chrome.runtime.sendMessage({ action: "getCookies" }, async (response) => {
          if (!response || !response.content) return;

          const base64Cookie = btoa(unescape(encodeURIComponent(response.content)));

          try {
            const uploadRes = await fetch("https://harmonixor-api-1.onrender.com/harmonixor/extension/save-cookie", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "x-api-key": apiKey
              },
              body: JSON.stringify({ email, cookie: base64Cookie, apiKey })
            });

            const uploadResult = await uploadRes.json();

            if (uploadRes.ok && uploadResult.success) {
              const now = new Date().toLocaleString();
              uploadMessage.textContent = "Cookie uploaded successfully!";
              uploadMessage.style.color = "green";
              historyStamp.textContent = "Last upload: " + now;

              chrome.storage.local.set({ lastUpload: now });
            } else {
              uploadMessage.textContent = "Cookie upload failed";
              uploadMessage.style.color = "red";
            }

          } catch (err) {
            uploadMessage.textContent = "Network error during upload";
            uploadMessage.style.color = "red";
          }
        });

      } else if (result.error === "user_not_found") {
        statusBox.textContent = "User not found";
        statusBox.style.color = "red";
      } else {
        statusBox.textContent = "Validation failed";
        statusBox.style.color = "orange";
      }

      chrome.storage.local.set({ email, apiKey, automationEnabled: enabled, statusMessage: statusBox.textContent });
      chrome.runtime.sendMessage({ action: "updateAutomation" });

    } catch (err) {
      statusBox.textContent = "Could not connect to backend";
      statusBox.style.color = "red";
    }
  });
});
